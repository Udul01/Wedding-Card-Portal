<div class="d-flex flex-row w-100" style="z-index: 999;">
                <div class="col-2 navbarBottom activeBtn">
                    <a href="cover.html">
                        <i class="bi bi-heart-fill"></i>
                        <!-- <img src="./images/Romantic-Couple-Silhouette-Minus-Ground.svg" alt=""> -->
                        Cover
                    </a>
                </div>
                <div class="col-2 navbarBottom">
                    <a href="couple.php">
                        <i class="bi bi-heart-fill"></i>
                        Couple
                    </a>
                </div>
                <div class="col-2 navbarBottom">
                    <a href="event.php">
                        <i class="bi bi-calendar-event-fill"></i>
                        Event
                    </a>
                </div>
                <div class="col-2 navbarBottom">
                    <a href="map.php">
                        <i class="bi bi-map-fill"></i>
                        Map
                    </a>
                </div>
                <div class="col-2 navbarBottom">
                    <a href="filter.php">
                        <i class="bi bi-instagram"></i>
                        Filter
                    </a>
                </div>
                <div class="col-2 navbarBottom">
                    <a href="gallery.php">
                        <i class="bi bi-image-fill"></i>
                        Gallery
                    </a>
                </div>
            </div>